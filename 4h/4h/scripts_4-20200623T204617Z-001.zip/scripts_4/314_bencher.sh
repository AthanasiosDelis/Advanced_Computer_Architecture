#!/bin/bash

# Advanced Computer Architecture, 2019-2020, 3.4.37.8
# 4th Assignment

# Benchmark Execution Script

# This assumes a directory tree like the following:
# Main Project dir  ${ACA_PATH}
# ├ CSLab code dir  ${HLP_PATH}
# ├ Sniper dir      ${SNP_PATH}
# └ Locks dir       ${LCK_PATH}

# ------------------------------------------------

# Project directory
ACA_PATH="/home/thanasis-linux" &> /dev/null

# Main directories
HLP_PATH="${ACA_PATH}/ex4-helpcode" &> /dev/null # CSLab Helper code & pintool

# Specific directories
LCK_PATH="${ACA_PATH}/real_locks"
OUT_PATH="${HLP_PATH}/output_314"

# ------------------------------------------------

declare -a Syncs=(
        "TAS_CAS"
        "TAS_TS"
        "TTAS_CAS"
        "TTAS_TS"
        "MUTEX"
)

declare -a Nthreads=(
        "1"
        "2"
 #       "4"
 #       "8"
 #       "16"
)

declare -a Grains=(
        "1"
        "10"
        "100"
)

for Sync in "${Syncs[@]}"; do

    for Nthread in "${Nthreads[@]}"; do

        for Grain in "${Grains[@]}"; do

            echo "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"
            echo " Launching ${Sync}, nthreads = ${Nthread}, grain = ${Grain}"
            echo "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"

            OUTDIR="${OUT_PATH}/${Grain}/${Sync}_${Nthread}"

            #${SNP_PATH}/run-sniper -c ${HLP_PATH}/ask4.cfg -n ${Nthread} --roi -g --
            #perf_model/l2_cache/shared_cores=${L2thread} -g --
            #perf_model/l3_cache/shared_cores=${L3thread} --
            ${LCK_PATH}/${Sync}/locks ${Nthread} 100000000 ${Grain} 

        done

    done

done
